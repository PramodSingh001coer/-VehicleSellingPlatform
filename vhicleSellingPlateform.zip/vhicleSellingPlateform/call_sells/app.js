const express = require('express');
const mysql = require('mysql');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const path = require('path');
const app = express();
const express = require('express');
const mongoose = require('mongoose');
const port = 3001;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the "public" directory
app.use(express.static('public'));

// List of bearer tokens
const bearerTokens = [];

// Connect to MongoDB server
mongoose.connect('mongodb://localhost/your_database', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => console.error('Could not connect to MongoDB', err));

    // Define schema for Vehicle
const vehicleSchema = new mongoose.Schema({
    title: String,
    description: String,
    price: Number,
    image: String
});

// Create a MySQL connection
const connection = mysql.createConnection({
    host: 'localhost', // or 'mysql-container' if your app is also running in a Docker container
    user: 'user', // the MYSQL_USER environment variable in your Dockerfile
    password: 'user', // the MYSQL_PASSWORD environment variable in your Dockerfile
    database: 'userDB',
    port: 3307 // the MYSQL_PORT environment variable in your DockerfileALTER USER 'user'@'localhost' IDENTIFIED WITH mysql_native_password BY 'user_password';
});
connection.connect(err => {
    if (err) {
        console.error('Error connecting to MySQL: ' + err.stack);
        return;
    }

    console.log('Connected to MySQL as id ' + connection.threadId);

    // Create a database
    connection.query('CREATE DATABASE IF NOT EXISTS userDB', (err, results) => {
        if (err) {
            console.error('Error creating database: ' + err.stack);
            return;
        }

        console.log('Database created or already exists');

        // Use the database
        connection.query('USE userDB', (err, results) => {
            if (err) {
                console.error('Error using database: ' + err.stack);
                return;
            }

            console.log('Using database');

            // Create a table
            const createTableSql = `
                CREATE TABLE IF NOT EXISTS users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(255) NOT NULL,
                    email VARCHAR(255) NOT NULL UNIQUE,
                    password VARCHAR(255) NOT NULL
                )
            `;
            connection.query(createTableSql, (err, results) => {
                if (err) {
                    console.error('Error creating table: ' + err.stack);
                    return;
                }

                console.log('Table created or already exists');
            });
        });
    });
});
// Middleware to check bearer token
app.use((req, res, next) => {
    if (req.path == '/') {
        const bearerToken = req.headers.authorization || req.body.authorization;
        if (!bearerToken || !bearerTokens.includes(bearerToken)) {
            res.sendFile(path.join(__dirname, 'public', 'pages/login.html'));
        }else{
            res.sendFile(path.join(__dirname, 'public', 'pages/homepage.html'));
        }
    }
    next();
});

const saltRounds = 10;

// Create Vehicle model
const Vehicle = mongoose.model('Vehicle', vehicleSchema);

app.get('/homepage', async (req, res) => {
    try {
        // Fetch vehicles from MongoDB
        const vehicles = await Vehicle.find();
        // Send vehicles to frontend
        res.send(vehicles);
    } catch (err) {
        res.status(500).send(err);
    }
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'pages/login.html'));
});



app.get('/registration', (req, res) => {

    console.log('Registration page');
    res.sendFile(path.join(__dirname, 'public', 'pages/registration.html'));
});
app.post('/registration', (req, res) => {
    const { name, email, password } = req.body.data;
    console.log(req.body.data);
    // Hash the password
    bcrypt.hash(password, 10, (err, hash) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'An error occurred while hashing the password' });
        }

        // Insert the user into the database
        const query = 'INSERT INTO users (name, email, password) VALUES (?, ?, ?)';
        connection.query(query, [name, email, hash], (err, results) => {
            if (err) {
                console.error(err);
                return res.status(500).json({ error: 'An error occurred while inserting the user into the database' });
            }

            res.status(201).json({ message: 'User registered successfully' });
        });
    });
});

app.listen(port, () => {
    console.log(`Server is running on port ${3001}`);
});
