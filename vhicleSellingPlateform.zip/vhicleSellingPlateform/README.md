# UMS

###### Project under assignment

### Assignment List
- [ ] Frontend (HTML, CSS, JavaScript)
- [ ] Server (Node.js, Express)
- [ ] Database (MongoDB)
